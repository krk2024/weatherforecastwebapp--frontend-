// Fetch weather data using AJAX
function fetchWeatherData(city = null, lat = null, lon = null) {
  const apiKey = '2d1b74f5ad0d95acfc6cf9bf6bdd5687';
  let apiURL;

  if (city) {
    apiURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
  } else if (lat && lon) {
    apiURL = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
  } else {
    alert("Invalid location data.");
    return;
  }

  const xhr = new XMLHttpRequest();
  xhr.open("GET", apiURL, true);

  xhr.onload = function () {
    if (xhr.status === 200) {
      const data = JSON.parse(xhr.responseText);
      document.getElementById("city_name").textContent = data.name;
      document.getElementById("country_name").textContent = data.sys.country;
      document.getElementById("main").textContent = data.weather[0].main;
      document.getElementById("temp").textContent = data.main.temp;
    } else {
      alert("City not found. Redirecting to homepage.");
      window.location.href = "index.html";
    }
  };

  xhr.onerror = function () {
    alert("An error occurred while fetching weather data.");
  };

  xhr.send();
}

// Fetch data based on query parameters
const params = new URLSearchParams(window.location.search);
const city = params.get("city");
const lat = params.get("lat");
const lon = params.get("lon");

if (city || (lat && lon)) {
  fetchWeatherData(city, lat, lon);
} else {
  alert("No city or location provided. Redirecting to homepage.");
  window.location.href = "index.html";
}
