// Redirect to the second page for forecast and history
function redirectToForecastPage() {
    const cityInput = document.getElementById("city").value.trim();
    if (cityInput) {
      window.location.href = `forecast.html?city=${encodeURIComponent(cityInput)}`;
    } else {
      alert("Please enter a city name.");
    }
  }
  
  // Fetch weather for the current location using AJAX
  function getCurrentLocationWeather() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;
        window.location.href = `forecast.html?lat=${latitude}&lon=${longitude}`;
      }, () => {
        alert("Unable to fetch location. Please try manually.");
      });
    } else {
      alert("Geolocation is not supported by your browser.");
    }
  }
  